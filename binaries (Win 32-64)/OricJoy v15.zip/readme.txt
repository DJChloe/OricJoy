Oric Joy v1.4
=============
Oric Joy will permit you to play oric games, with your gamepad
In OricJoy Itself :
- select "D-Pad" (default) if you use the direction pad of a gamepad (the dirrectional cross, such like a vintage nintendo controler)
  or select analog if you use an analog joystick or if you prefer to use the left analog stick of a gamepad.
- If you click once on a game thumbnail, the teaser is displayed in the bottom part.
- Double click on a game to launch it in oricutron.
- In oricutron, if you want to quit, right click with your mouse and select quit in the menu.

In the "games" directory, you will find the game profiles.
- Each profile is a sub-directory.
- The name of the sub-directory will appear in Oric Joy as the name of the game ("4K Kong, Hopper,...")
- in a sub-directory profile, 3 files are required and 1 is optional :
	- command.txt (see details below)
        - a graphic file (for the inlay, name is not important, but the extension CAN BE .jpg, .jpeg, .png or .bmp )
          this file can be a screenshot, or a tape-box-cover scan.
        - a .tap or a .dsk file
        - teaser.txt is a short explanation text about the game, this is an optional file
   
command.txt file
----------------
This file is the most important. It the one that permits to map the Oric keys to your gamepad buttons.
Any ps3 controller will do the job. Mine is a SOG wired gamepad (SOG = "spirit of gamers"). Yeah, it's a crap, but it works.
On the left field, just before the equal sign, you will find the controller buttons you need to map, namely :
  - up,bottom,left,right (D-Pad or Left analog)
  - b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11 and b12 (that should be enough, even if technically, it is possible to map 32 buttons).
  
For helping you, see the PS3_controller Button map.jpg file.
Another help is located at the top-left of the Oric joy windows. If your joystick is connected, text boxes representing each controller button will show up in red.

In the right field (after the equal sign), you will provide...
    ... either one of those Special keys :
	up
	down
	left
	right
	space
	del
	ctrl
	return
	shift (stands for left shift)
	lshift (left shit)
	rshift (right shift)
	esc

   ...or one single char:
      Without quote just after the equal sign, namely :
         - numbers : 0,1,2,3,4,5,6,7,8,9
         - alphabet : a,b, .., z
         - special chars corresponding to each key of the oric keyboard : [ ] ; : ' " , < . > / and ?

   ...specials
      - keepdown=0 (default)/keepdown=1
           this permits (when set to 1), to keep keys down (see crocky profile) until another direction is pressed.
      - up-left, down-left, up-right, down-right : for diagonal directions (see Hu-bert profile)

      Note: the file is not case sensitive, you can write everything in lower or upper case.


Enjoy,
Chloe Avrillon